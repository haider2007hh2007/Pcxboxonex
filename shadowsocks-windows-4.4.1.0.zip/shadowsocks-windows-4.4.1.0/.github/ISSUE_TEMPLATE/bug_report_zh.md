---
name: Bug报告 （中文）
about: 反馈Bug
title: ''
labels: bug report
assignees: ''

---

<!--
- 影梭（Shadowsocks）是一个开源非盈利项目，不提供任何托管服务。如果你是从服务提供商购买的服务，请联系他们。
- 如果你有非影梭Windows客户端相关的问题，请去 https://github.com/shadowsocks
- 提问前请先阅读wiki https://github.com/shadowsocks/shadowsocks-windows/wiki/Troubleshooting.
- 并在Issue Board中搜索 https://github.com/shadowsocks/shadowsocks-windows/issues?utf8=%E2%9C%93&q=is%3Aissue
- 请按照以下格式描述你的问题，描述不清的问题将会被关闭。
-->

### 简要描述问题

### 环境

- Shadowsocks客户端版本：
- 操作系统版本：
- .NET版本：

### 操作步骤


### 期望的结果


### 实际结果


### 配置文件和日志文件（请隐去敏感信息）

```
在此粘贴日志
```
